插件目录
========

每个子文件夹是一个插件：
  plugins/<id>/plugin.json   必填
  plugins/<id>/plugin.py     可选

plugin.json 示例：
{"id":"hello","name":"示例","version":"1.0","enabled":true}

plugin.py 可写钩子：on_start(app) / on_check(app, lesson, result) / on_finish(app)
删掉文件夹即卸载，不用改主程序。
